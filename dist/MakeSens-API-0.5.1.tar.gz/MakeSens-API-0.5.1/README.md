# MakeSensAPI_Python
En este repositorio, se plantea documentar la API para extraer datos de Makesens-Cloud Prueba
