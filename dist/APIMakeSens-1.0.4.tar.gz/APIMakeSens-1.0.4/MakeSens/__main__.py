def main():
    print("To make use of the MakeSens API import the package to your project")
    
if __name__ == "__main__":
    main()